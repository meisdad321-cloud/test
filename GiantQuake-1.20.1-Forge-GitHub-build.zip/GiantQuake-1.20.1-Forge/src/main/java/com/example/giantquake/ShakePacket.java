package com.example.giantquake;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ShakePacket {
    private final float strength;
    private final int duration;

    public ShakePacket(float strength, int duration) {
        this.strength = strength;
        this.duration = duration;
    }

    public static void encode(ShakePacket packet, FriendlyByteBuf buf) {
        buf.writeFloat(packet.strength);
        buf.writeVarInt(packet.duration);
    }

    public static ShakePacket decode(FriendlyByteBuf buf) {
        return new ShakePacket(buf.readFloat(), buf.readVarInt());
    }

    public static void handle(ShakePacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientShakeHandler.start(packet.strength, packet.duration)));
        context.setPacketHandled(true);
    }
}
