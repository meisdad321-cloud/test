package com.example.giantquake;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

public class GiantStepHandler {
    private static final Map<Entity, StepState> STATES = new WeakHashMap<>();
    private static final double MIN_SCALE = 2.0;
    private static final int MAX_RADIUS = 5;

    private static final class StepState {
        double x, z, distance;
        boolean initialized;
    }

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide || !entity.isAlive()) return;

        double scale = readPehkuiScale(entity);
        if (scale < MIN_SCALE) {
            STATES.remove(entity);
            return;
        }

        StepState state = STATES.computeIfAbsent(entity, e -> new StepState());
        double x = entity.getX();
        double z = entity.getZ();

        if (!state.initialized) {
            state.x = x;
            state.z = z;
            state.initialized = true;
            return;
        }

        double dx = x - state.x;
        double dz = z - state.z;
        state.x = x;
        state.z = z;

        if (!entity.onGround() || entity.isPassenger() || entity.isInWaterOrBubble()) return;

        double moved = Math.sqrt(dx * dx + dz * dz);
        if (moved < 0.002) return;
        state.distance += moved;

        double stepLength = Math.max(0.9, Math.min(5.5, scale * 0.30));
        if (state.distance >= stepLength) {
            state.distance = 0;
            stomp((ServerLevel) entity.level(), entity, scale);
        }
    }

    private void stomp(ServerLevel level, LivingEntity giant, double scale) {
        double radius = Math.max(2.0, Math.min(20.0, scale * 0.55));
        int blockRadius = Math.max(1, Math.min(MAX_RADIUS, (int)Math.ceil(scale * 0.12)));
        BlockPos foot = BlockPos.containing(giant.getX(), giant.getY() - 0.08, giant.getZ());

        level.sendParticles(ParticleTypes.CLOUD, giant.getX(), giant.getY() + 0.1,
                giant.getZ(), 36, Math.min(2.5, radius * 0.22), 0.08,
                Math.min(2.5, radius * 0.22), 0.08);
        level.sendParticles(ParticleTypes.POOF, giant.getX(), giant.getY() + 0.1,
                giant.getZ(), 16, Math.min(1.8, radius * 0.16), 0.06,
                Math.min(1.8, radius * 0.16), 0.04);
        level.playSound(null, giant.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                SoundSource.HOSTILE, 0.75F, 0.55F);

        AABB area = new AABB(giant.getX() - radius, giant.getY() - 1.5,
                giant.getZ() - radius, giant.getX() + radius, giant.getY() + 3.0,
                giant.getZ() + radius);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != giant && e.isAlive() && !e.isAlliedTo(giant))) {
            double tx = target.getX() - giant.getX();
            double tz = target.getZ() - giant.getZ();
            double distance = Math.max(0.5, Math.sqrt(tx * tx + tz * tz));
            double strength = Math.max(0.0, 1.0 - distance / radius);
            target.knockback(0.8 + strength * Math.min(2.8, scale * 0.08),
                    -tx / distance, -tz / distance);
            if (target instanceof ServerPlayer player) {
                NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                        new ShakePacket((float)(0.4 + strength * Math.min(1.8, scale * 0.07)), 12));
            }
        }

        // Break only ordinary, breakable terrain; never touch block entities or protected blocks.
        for (int ox = -blockRadius; ox <= blockRadius; ox++) {
            for (int oz = -blockRadius; oz <= blockRadius; oz++) {
                if (ox * ox + oz * oz > blockRadius * blockRadius) continue;
                for (int oy = -1; oy <= 0; oy++) {
                    BlockPos pos = foot.offset(ox, oy, oz);
                    if (!level.hasChunkAt(pos)) continue;
                    BlockState block = level.getBlockState(pos);
                    if (block.isAir() || block.hasBlockEntity()) continue;
                    if (block.is(Blocks.BEDROCK) || block.is(Blocks.BARRIER)
                            || block.is(Blocks.END_PORTAL) || block.is(Blocks.END_PORTAL_FRAME)
                            || block.is(Blocks.COMMAND_BLOCK) || block.is(Blocks.CHAIN_COMMAND_BLOCK)
                            || block.is(Blocks.REPEATING_COMMAND_BLOCK) || block.is(Blocks.STRUCTURE_BLOCK)
                            || block.is(Blocks.JIGSAW)) continue;

                    float hardness = block.getDestroySpeed(level, pos);
                    if (hardness < 0 || hardness > (scale >= 12 ? 3.5F : 2.0F)) continue;
                    level.destroyBlock(pos, true, giant);
                }
            }
        }
    }

    /**
     * Pehkui is optional at compile time. If installed, read ScaleTypes.BASE through reflection.
     * Without Pehkui the entity is treated as normal-sized.
     */
    private static double readPehkuiScale(Entity entity) {
        try {
            Class<?> scaleTypes = Class.forName("virtuoel.pehkui.api.ScaleTypes");
            Field baseField = scaleTypes.getField("BASE");
            Object baseType = baseField.get(null);
            Method getScaleData = baseType.getClass().getMethod("getScaleData", Entity.class);
            Object scaleData = getScaleData.invoke(baseType, entity);
            Method getScale = scaleData.getClass().getMethod("getScale");
            return ((Number)getScale.invoke(scaleData)).doubleValue();
        } catch (Throwable ignored) {
            // Some Pehkui releases expose implementation classes through interfaces; try public API method.
            try {
                Class<?> scaleTypes = Class.forName("virtuoel.pehkui.api.ScaleTypes");
                Object baseType = scaleTypes.getField("BASE").get(null);
                for (Method method : baseType.getClass().getMethods()) {
                    if (method.getName().equals("getScaleData") && method.getParameterCount() == 1) {
                        Object data = method.invoke(baseType, entity);
                        for (Method getter : data.getClass().getMethods()) {
                            if (getter.getName().equals("getScale") && getter.getParameterCount() == 0) {
                                return ((Number)getter.invoke(data)).doubleValue();
                            }
                        }
                    }
                }
            } catch (Throwable ignoredAgain) {}
            return 1.0;
        }
    }
}
