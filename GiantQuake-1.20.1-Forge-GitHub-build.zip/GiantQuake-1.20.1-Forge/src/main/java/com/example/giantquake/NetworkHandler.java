package com.example.giantquake;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.SimpleChannel;

public final class NetworkHandler {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GiantQuake.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals
    );

    private NetworkHandler() {}

    public static void register() {
        CHANNEL.messageBuilder(ShakePacket.class, 0)
                .encoder(ShakePacket::encode)
                .decoder(ShakePacket::decode)
                .consumerMainThread(ShakePacket::handle)
                .add();
    }
}
