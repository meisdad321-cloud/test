# Giant Quake — Forge 1.20.1

This is the source project for a Minecraft Java Edition 1.20.1 Forge mod.

## Features
- Reads Pehkui's BASE scale when Pehkui is installed; no duplicate scale command is added.
- Giant entities produce a ground-impact particle burst and heavy impact sound while walking.
- Nearby non-allied living entities are knocked back.
- Nearby server players receive a client camera-shake packet.
- The impact breaks ordinary terrain in a small footprint, with harder blocks allowed at larger scales.
- Bedrock, barriers, portal blocks, command blocks, structure blocks, jigsaws, and block entities are protected.

## Requirements
- Minecraft Java 1.20.1
- Minecraft Forge 47.x (build configured for 47.4.20)
- Java 17
- Pehkui for scaling detection and scale commands

## Build
From a computer with network access and Gradle installed:
1. Extract this project.
2. Run `gradle build` (or import the folder into IntelliJ IDEA and use the Gradle task `build`).
3. The jar will be in `build/libs/GiantQuake-1.0.0.jar`.
4. Put the built jar in `mods` alongside Forge and Pehkui.

This environment could not download Forge/Gradle dependencies, so this delivery is source code and is not a precompiled jar. The project has not been launched in Minecraft; build and runtime testing are still required.

## Usage
Use Pehkui's command directly, for example:
`/scale set pehkui:base 16 @s`

Move while grounded to trigger steps. Larger scales create larger shockwaves and stronger knockback. Terrain destruction is deliberately capped to avoid destroying a huge area every tick.
