package com.example.giantquake;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.common.MinecraftForge;

@Mod(GiantQuake.MODID)
public class GiantQuake {
    public static final String MODID = "giantquake";

    public GiantQuake() {
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new GiantStepHandler());
    }
}
