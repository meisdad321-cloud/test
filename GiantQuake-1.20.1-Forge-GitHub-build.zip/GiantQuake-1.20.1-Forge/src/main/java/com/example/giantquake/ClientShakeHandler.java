package com.example.giantquake;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GiantQuake.MODID, value = Dist.CLIENT)
public class ClientShakeHandler {
    private static float strength;
    private static int ticksLeft;
    private static int totalTicks;

    public static void start(float newStrength, int duration) {
        strength = Math.max(strength, Math.min(3.0F, newStrength));
        ticksLeft = Math.max(ticksLeft, Math.min(30, duration));
        totalTicks = Math.max(1, ticksLeft);
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (ticksLeft > 0) {
            ticksLeft--;
            strength *= 0.88F;
        } else {
            strength = 0;
        }
    }

    @SubscribeEvent
    public static void cameraShake(ViewportEvent.ComputeCameraAngles event) {
        if (ticksLeft <= 0 || strength <= 0.01F) return;
        float fade = (float)ticksLeft / Math.max(1, totalTicks);
        float amount = strength * fade;
        long time = System.nanoTime() / 1000000L;
        event.setPitch(event.getPitch() + (float)Math.sin(time * 0.041) * amount * 1.6F);
        event.setYaw(event.getYaw() + (float)Math.cos(time * 0.033) * amount * 1.1F);
        event.setRoll(event.getRoll() + (float)Math.sin(time * 0.052) * amount * 0.7F);
    }
}
